# AOS/OMP separation supplemental snapshot

- Repo: `C:/dev/copicu`
- Snapshot: `2026-08-07T16:51:14+00:00`
- Restore procedure (from any directory; overwrites only archived paths):

```powershell
powershell -NoProfile -Command "$z='C:\dev\copicu\archive\aos-omp-separation-2026-08-07-2.zip'; $d='C:\dev\copicu'; Add-Type -AssemblyName System.IO.Compression.FileSystem; $a=[IO.Compression.ZipFile]::OpenRead($z); try { foreach($e in $a.Entries){ if($e.FullName -eq 'manifest.md' -or $e.FullName.EndsWith('/')){continue}; $p=Join-Path $d ($e.FullName.Replace('/','\')); [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($p)) | Out-Null; [IO.Compression.ZipFileExtensions]::ExtractToFile($e,$p,$true) } } finally { $a.Dispose() }"
```

| Origin relative | Snapshot | SHA-256 |
| --- | --- | --- |
| `docs/topics/local-codex-skills.md` | `2026-08-07T16:51:14+00:00` | `06e2caf1584a9fb55f564df77320593af133d87e60d9173454ec034d7cb95099` |
