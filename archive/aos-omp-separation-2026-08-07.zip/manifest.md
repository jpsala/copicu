# AOS/OMP separation snapshot

- Repo: `C:/dev/copicu`
- Snapshot: `2026-08-07T16:44:35+00:00`
- Restore procedure (from any directory; overwrites only archived paths):

```powershell
powershell -NoProfile -Command "$z='C:\dev\copicu\archive\aos-omp-separation-2026-08-07.zip'; $d='C:\dev\copicu'; Add-Type -AssemblyName System.IO.Compression.FileSystem; $a=[IO.Compression.ZipFile]::OpenRead($z); try { foreach($e in $a.Entries){ if($e.FullName -eq 'manifest.md' -or $e.FullName.EndsWith('/')){continue}; $p=Join-Path $d ($e.FullName.Replace('/','\')); [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($p)) | Out-Null; [IO.Compression.ZipFileExtensions]::ExtractToFile($e,$p,$true) } } finally { $a.Dispose() }"
```

| Origin relative | Snapshot | SHA-256 |
| --- | --- | --- |
| `AGENTS.md` | `2026-08-07T16:44:35+00:00` | `edb0fbdd589e584e31ce8bc5313be76324c0db423c58fdc1f98b28f781d9cf1f` |
| `package.json` | `2026-08-07T16:44:35+00:00` | `7a4e2fba75750872ce32c8f6f6968a758838c24ac6f609a9b0baefb39edfe165` |
| `docs/ASSISTANT_RULES.md` | `2026-08-07T16:44:35+00:00` | `babdc100818c0c03b296051290bc877f216be928da64f411a0f49bbfda3c0e69` |
| `docs/DECISIONS.md` | `2026-08-07T16:44:35+00:00` | `3ca56ef2fc2d361ca940c932456f2942508dddc6aa403991ba2deef6b1a077e4` |
| `docs/GLOSSARY.md` | `2026-08-07T16:44:35+00:00` | `5dcfe9e97bd6494bc4aad87ef955af79687d812ce732d01c9a8cc2f56f66da47` |
| `docs/OS_PLAYBOOK.md` | `2026-08-07T16:44:35+00:00` | `d70ef7142b60cac962fd3503fb9421d2064988b812cb81992134d4c6856df869` |
| `docs/README.md` | `2026-08-07T16:44:35+00:00` | `f2374fa32c8b0178d9e558d821af555af3cb46d0734e9c9dc6084e8113c5ee8f` |
| `docs/TOPICS.md` | `2026-08-07T16:44:35+00:00` | `319d8d4beece14585128656ba94b94e256cd2f361aa35a986003d5d63dd8f066` |
| `docs/USER_GUIDE.md` | `2026-08-07T16:44:35+00:00` | `3a2b21fe87dbfc0367223b928a58b128e2410b76c41d7c11ef3c2bf1586e770c` |
| `docs/WORKING_MEMORY.md` | `2026-08-07T16:44:35+00:00` | `e28940ae2d60e806389f2d4c13b9e178968835eb038c732e51784772772683b6` |
| `docs/topics/agent-tool-routing.md` | `2026-08-07T16:44:35+00:00` | `bef14e8a86e733cf7019b13646edd62eed54d750bdfaeede8e8ff0144f86caef` |
| `docs/topics/docs-knowledge-system.md` | `2026-08-07T16:44:35+00:00` | `498f6e1e8b83b74ac633fde13b553fefbf6c025d2a4625eeb03c09e0b6c0c2cf` |
| `docs/topics/omp-agentic-os.md` | `2026-08-07T16:44:35+00:00` | `3f80c3fa9e4bc56052607a89fe66519f4869bace5cbcdaf0d1d1945623e6a7f6` |
| `docs/topics/portable-multiharness-contract.md` | `2026-08-07T16:44:35+00:00` | `5eb46c74bfddd6d8bade3690bcc883ec65735cf947ca9e5ac5a5b9d825bb97fe` |
| `docs/topics/os-quality.md` | `2026-08-07T16:44:35+00:00` | `68c3b865b7eba2b90c56021f44995669a832e30fe387f03b973539739df8ff74` |
| `docs/topics/technical-research-process.md` | `2026-08-07T16:44:35+00:00` | `da9236474c881e9244527d15a12dd71314947f1dbb1466b52381992564cb2a48` |
| `docs/topics/minimal-implementation.md` | `2026-08-07T16:44:35+00:00` | `22f7d49c3d774421a615d5bc2879d23432e275a68033531a95c5c5f989bb4237` |
| `docs/tracks/README.md` | `2026-08-07T16:44:35+00:00` | `5091eaeea1d3a10ed237f91cc4cb3f9204ec1f6963443a368749eb33b4adeb40` |
| `docs/reference/tool-routing.yaml` | `2026-08-07T16:44:35+00:00` | `27b401426b7143d4d9d259d4e385645416300febbed0a8f21bef301a8d7d0b6a` |
| `docs/reference/omp-agentic-os-command-surface.md` | `2026-08-07T16:44:35+00:00` | `069ca5f6dbae2950bcf29a99d70273a7e161ad47a5f7af1ff4ca2141fec85751` |
| `docs/reference/pi-extension-stack-history.md` | `2026-08-07T16:44:35+00:00` | `9bc9494ae061fb387f84354c0a3559c69e7eb65a46bb817ee434ba0d62a14e68` |
| `scripts/agent-context-audit.ts` | `2026-08-07T16:44:35+00:00` | `d88fa0d4c7129a60f4b3711f659f59caa3e28d47b4cd2fd28e9b9919986b815f` |
| `scripts/context-index.ts` | `2026-08-07T16:44:35+00:00` | `59a36d3f25494b7311dfce187e92f6581024c7de03221a08f2f2edad4820284e` |
| `scripts/check-tool-routing.ts` | `2026-08-07T16:44:35+00:00` | `bb49908250097c0c7e28c6b078be62a21a4c10f7838121060f8498e0d37ca0e9` |
| `scripts/traycer-routing-check.ts` | `2026-08-07T16:44:35+00:00` | `372bb16053da5400264a8e6aa95286f2241ac8f29881c702a43125a0ce1e13a1` |
| `scripts/traycer-routing-contract.ts` | `2026-08-07T16:44:35+00:00` | `0cd057837d45a2afa652a353609a42296d168733b9015f71f5aafb947744d4e9` |
| `scripts/traycer-routing-contract.test.ts` | `2026-08-07T16:44:35+00:00` | `9add206bd3bd2faed9059078f28c6a5394df680f85d6fcd5955f6f04a7cf77f3` |
