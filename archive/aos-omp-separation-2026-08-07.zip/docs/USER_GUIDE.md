# Guía De Usuario Del Sistema Agentico

Copicu es un downstream agentic local sobre OMP nativo. Conserva contexto y
skills útiles para el producto, sin copiar runtime, registry, memoria ni gobierno
de otro manager.

## Uso Diario

Usá intención conversacional directa:

- conversar o investigar no implementa;
- pedir un plan produce un plan y no lo ejecuta;
- pedir implementación actúa en la sesión actual;
- pedir persistencia guarda una sola vez sólo valor durable faltante.

No se abre otra sesión, crea handoff ni autoenvía por rutina. `Sol Medium` es la
ruta normal; High se reserva para riesgo o ambigüedad material. No hay fallback
automático de modelo, provider o auth.

`realinear os` sigue disponible como operación de auditoría. `computer` es el
built-in OMP para dogfood explícito: está fuera del runtime de producto, exige
aviso antes de UI visible y mantiene aprobación para input. El oracle C0 siempre
parte de una app externa y escribe tras `Ctrl+Shift+.` sin enfocar Copicu
manualmente.

## Modelo Mental

- `AGENTS.md`: reglas mínimas.
- `docs/.generated/context-index.md`: índice generado.
- `docs/WORKING_MEMORY.md`: foco y estado vivo.
- `docs/TOPICS.md`: router humano.
- `docs/topics/`: conocimiento reusable.
- `docs/tracks/`: briefs y trabajo retomable.
- `docs/skills/`: skills locales portables.
- `docs/DECISIONS.md`: decisiones durables.
- `specs/`: features grandes.

La memoria principal son los docs versionados, no la conversación ni un prompt de
handoff. La ruta caliente debe permanecer corta.

## Verificación

```powershell
bun run context:index
bun run context:audit
bun run routing:check
npm run skills:status
```

Installs, commit, push, deploy, producción, credenciales, datos privados y efectos
externos conservan confirmación explícita.
