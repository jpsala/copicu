# OMP Agentic OS Surface

Estado canónico: OMP nativo.

## Superficie Diaria

| Intención | Resultado |
| --- | --- |
| Conversar o investigar | Responder e inspeccionar; no editar por inferencia. |
| Pedir un plan | Producir un plan; no ejecutarlo. |
| Pedir implementación | Actuar en la sesión actual con tools nativas y evidencia focal. |
| Pedir persistencia | Guardar una sola vez sólo el valor durable faltante. |

No hay comando lifecycle, package global, handoff automático ni nueva sesión de
rutina. `Sol Medium` es la ruta normal; High se reserva para riesgo o ambigüedad
material y no hay fallback automático de modelo, provider o auth.

## Capabilities Locales

- `computer` es el built-in OMP habilitado por `.omp/config.yml` para dogfood
  explícito. Inspecciones usan `read_only: true`; input requiere aprobación.
- `docs/skills/` es el canon de skills locales y `.agents/skills` conserva
  discovery OMP.
- `.omp/commands/research.md` porta el único prompt con consumidor real; release
  usa su script/documentación canónica y los taskflows Pi quedan sólo en backup.

## Contrato De Computer

No existe extensión local ni wrapper AHK. Elegir exactamente una ventana,
preferir AX y validar WebView2 con screenshot/estado real. Todo click por
coordenadas requiere un screenshot reciente del mismo target. El oracle C0
requiere app externa enfocada, `Ctrl+Shift+.` con entrega foreground, escritura
global inmediata sin obtener/targetear Copicu y token visible en search.
