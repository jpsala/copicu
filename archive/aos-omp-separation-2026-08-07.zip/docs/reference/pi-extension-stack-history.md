---
id: pi-extension-stack
status: reference
kind: reference
triggers:
  - extensiones pi
  - paquetes pi
  - pi packages
  - sincronizar pi
  - web_search
  - web_research
  - codemapper
  - fff
  - fffind
  - ffgrep
  - taskflow
  - pi-code-planner
  - advisor
  - pi-lens
  - pi-footer
  - image_generate
primary_refs:
  - C:/dev/os/docs/reference/pi-extension-stack-inventory.md
  - docs/topics/omp-agentic-os.md
  - docs/topics/agent-tool-routing.md
  - docs/reference/tool-routing.yaml
  - docs/OS_PLAYBOOK.md
---

# Pi Extension Stack

Referencia histórica del stack Pi que puede aparecer en tracks antiguos. No
define el routing actual: Copicu usa tools OMP nativas y
`docs/topics/agent-tool-routing.md`. El inventario global de Pi permanece fuera
del repo y no es dependencia local de Copicu.

## Regla Operativa

1. Elegir la herramienta mas chica que cierre el objetivo.
2. Usar web cuando conocimiento externo/versionado evite adivinar.
3. Antes de instalar/remover paquetes globales, pedir permiso y hacer backup de
   `C:/Users/jpsal/.pi/agent/settings.json`.
4. Despues de cambios Pi, correr `/reload` y smoke-testear la capacidad tocada.

## Superficie Histórica Pi

| Nivel | Tools | Uso |
| --- | --- | --- |
| Core diario | `fffind`, `ffgrep`, CodeMapper (`map/search/outline`), `ask_user`, `advisor`, `lens_diagnostics` | Orientacion, decisiones humanas, segundo juicio y feedback tecnico. |
| Orquestacion | `taskflow`, `pi-council`, `pi-link` | Auditorias/reviews paralelas con ownership claro; no para trabajo serial chico. |
| Piloto opt-in | `pi-dynamic-workflows` via `C:/dev/os/docs/skills/aos-dynamic-workflows-pilot/` si se instala | Comparar fan-out pesado/deep research/adversarial review contra `taskflow`; no dejar triggers genericos activos. |
| Ejecución actual | Intención OMP en la sesión actual; subagentes sólo por pedido explícito | No activar loops autónomos ni crear handoffs o sesiones por rutina. |
| Research externo | `web_search`, `fetch_content`, `web_answer`, `web_research`, skill `librarian` | Usar para docs, releases, issues, APIs, internals OSS; no enviar secretos. |
| Visual/UI | `pi-chrome`, `cua-driver`, `image_generate`, `aos-impeccable` | UI, browser signed-in y assets; pedir aprobacion para cuentas reales/envios/material privado. |
| Global/optional | footer, Telegram/Discord remotes, MCP, RTK, themes, shims | Entorno externo; no copiarlos como dependencia local ni usarlos si no aportan. |



## Fleet Updates AOS

Para actualizar varias repos AOS en orden, usar `/aos-fleet-update` como
superficie local. El comando genera un `pi_long_task` serial con TODO markdown,
allowlist de paths AOS, checks por repo y commits locales opcionales.

No usar `dgoal` para este caso mientras su startup gate dependa de confirmacion
modal fragil, fallback chino sin `pi-di18n`, y abandono por feedback vacio.

## Pi Dynamic Workflows Trigger Seguro

`pi-dynamic-workflows` queda explicito-only. Default seguro:

```json
{
  "keywordTriggerEnabled": false,
  "keywordTriggerWord": "pi-workflow"
}
```

Guardar `C:/Users/jpsal/.pi/workflows/settings.json` como JSON UTF-8 sin BOM. Si aparece `[workflows mode is ON]` al escribir mensajes normales, la config probablemente no fue parseada y el paquete volvio al trigger default `workflow`; reescribir el JSON sin BOM, correr `/reload` y verificar `/workflows-trigger status`.

## Research / Web

- `web_search`: descubrir fuentes con 2-4 queries variadas.
- `fetch_content`: leer fuentes candidatas antes de decidir.
- `web_answer`: factual chico con grounding rapido.
- `web_research`: informe asincronico para temas amplios.
- `librarian`: internals de librerias open-source con permalinks.

Playbook: `docs/topics/conversational-research.md`.

## Busqueda Local Y Codigo

- `fffind`/`ffgrep`: ubicar archivos o texto arbitrario rapido.
- CodeMapper `map/search/outline/expand/path`: estructura, simbolos y relaciones.
- `pi-lens`: LSP/diagnostics/AST; es feedback tecnico, no reemplaza checks del repo.

## Planning Y Ejecución Actual

La intención conversacional distingue discusión, plan e implementación. La
implementación actúa en la sesión actual; para cambios chicos se priorizan
inspección mínima y checks focales. Todos o subagentes se agregan sólo según
necesidad y política explícita. El contrato verificable vive en
`docs/reference/tool-routing.yaml`.

## UI / Browser / Computer Use

Browser, `computer` e image-gen actúan sobre la máquina o servicios externos.
Aplican las reglas de `AGENTS.md`: avisar antes de UI visible, no tocar cuentas
o canales reales ni enviar datos privados sin permiso y guardar evidencia
reproducible. Para Copicu, usar el `computer` built-in; no Cua Driver ni wrapper.

## Footer / Statusline

`pi-footer` es la pieza correcta para ajustar statusline/footer. La config e
inventario global se documentan en
`C:/dev/os/docs/reference/pi-extension-stack-inventory.md`; no convertirlos en
memoria local de Copicu.

## Sincronizar Otra PC

1. Comparar `C:/Users/jpsal/.pi/agent/settings.json`.
2. Revisar paquetes en `~/.pi/agent/npm` y git skills/extensiones.
3. Verificar extras: `C:\dev\pi`, API keys, CLIs opcionales, ffmpeg si aplica.
4. Smoke-testear solo capacidades clave: `ask_user`, FFF, taskflow, footer y la
   herramienta modificada.

## Aprendizajes Recientes

Solo guardar aca aprendizajes de runtime Pi o patrones agenticos genericos que
afecten a Copicu. No incluir fixes de producto, canales, credenciales ni datos
downstream. El inventario historico/global queda en
`C:/dev/os/docs/reference/pi-extension-stack-inventory.md`.
